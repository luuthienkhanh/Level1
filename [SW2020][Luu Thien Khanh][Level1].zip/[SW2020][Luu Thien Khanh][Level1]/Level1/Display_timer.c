#include "lcd.h"
#include "r_spi_if.h" 
#include "Display_timer.h"
#include "stdio.h"
#include <string.h>
extern int second;
extern int minute;
char * string_shown_on_lcd[10];

/***************************************************************************************
* Function Name: Display_timer
* Description  : Diplay timer
* Arguments    : none
* Return Value : none
****************************************************************************************/
void Display_timer(void){
	int a=0;
	char * string_shown_on_lcd[10];
	if (second<=9&&minute<=9){
		         int a=0;
	                 sprintf((char *)string_shown_on_lcd, "%d%d:%d%d",a,minute,a,second);
                         DisplayLCD(LCD_LINE3, (uint8_t*)string_shown_on_lcd);
                        }else if (second>9&&minute<9){
                         sprintf((char *)string_shown_on_lcd, "%d%d:%d",a,minute,second);
                         DisplayLCD(LCD_LINE3, (uint8_t*)string_shown_on_lcd);
                        }else if ( second<=9&&minute>9){
                         sprintf((char *)string_shown_on_lcd, "%d:%d%d",minute,a,second);
                         DisplayLCD(LCD_LINE3,(uint8_t*)string_shown_on_lcd);
			}
			else {sprintf((char *)string_shown_on_lcd, "%d:%d",minute,second);
                         DisplayLCD(LCD_LINE3, (uint8_t*)string_shown_on_lcd);
                        }	
		}