#include "r_macro.h"
#include "r_spi_if.h"
#include "lcd.h"      /* LCD driver interface */
#include "Port.h"
#include "iodefine.h"
#include "Check_Switch.h"

#define SETTING 1
#define PAUSED 2
#define COUNTING 3

extern int second;
extern int minute;
extern int status;
extern int Sw;

/******************************************************************************
* Function Name: Check_Switch
* Description  : Action for each switch
* Arguments    : none
* Return Value : none
******************************************************************************/
void Check_Switch(void) {
	    
	    switch (Sw){
		    case 1:/* Actions if Switch 1 are pressed */
	                   {   
		           status = SETTING;
		           second = second +1;
		           if (second >=59){
		           second=59;
		           }
			   }
			   break;
	    
	            case 2: /* Actions if Switch 2 are pressed */
	                   {if (status==PAUSED){
	                    minute = 0;
	                    second = 0;
	                    } else {minute = minute +1;
	                      if (minute>=59){
		              minute=59;
	                     }
	                   }
	                   status = SETTING;
	                   }
			   break;
                    case 3: /* Actions if Switch 3 are pressed */
		          {
		           if (status == COUNTING){
		           status = PAUSED;
		          }
		           else if ((status == PAUSED)&&(minute!=0||second!=0)){
		           status = COUNTING;
		          }
		          else if ((status == SETTING)&&(minute!=0||second!=0)){
		          status = COUNTING;
		    }     
	            }
			   break;
		   default : break;
	
	    }
}