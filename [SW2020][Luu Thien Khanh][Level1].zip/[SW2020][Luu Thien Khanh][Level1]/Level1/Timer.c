//#include "lcd.h"      /* LCD driver interface */ 
#include "Display_timer.h"
#include "Display_Status.h"
#define SETTING 1
extern Wait1CentiSecond();
extern int time_change;
extern int minute;
extern int second;
extern int status;
int G_elapsedTime = 0;

/***************************************************************************************
* Function Name: Timer
* Description  : Base on time_change flag to run timer or not, display timer and status
* Arguments    : none
* Return Value : none
****************************************************************************************/
void Timer (void){
	if (time_change==1){
		//Assembly code, wait 0,01s
		//Wait1CentiSecond();
		
		//C code, wait 0.01s
		unsigned long t =10*1778;
                while (t!=0) t--;
		
		G_elapsedTime++;
		if (G_elapsedTime >= 100)// G_elapsedTime = 100, wait 1s
		{
			G_elapsedTime = G_elapsedTime - 100; 
		        second= second - 1;	
	                if (second==-1&&minute!=0) {
			minute--;
			second=59;
		        }else if (second==0&&minute==0){
			second=0;
			minute=0;
			status=SETTING;
		       }
			
                 Display_timer();
		 Display_Status();
	}}
	else {
	     unsigned long i =50*1778;
             while (i!=0) i--;
	     Display_timer();
	     Display_Status();
	}
}
	      



	