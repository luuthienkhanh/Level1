#include "lcd.h"      /* LCD driver interface */
#include "Check_Status.h"
#include "Timer.h"
#define SETTING 1
#define PAUSED 2
#define COUNTING 3
extern int status;
extern int time_change;

/*********************************************************************************************
* Function Name: Check_Status
* Description  : Check status to enable time_change flag to enable timer
* Arguments    : none
* Return Value : none
*********************************************************************************************/
void Check_Status(void){
	switch (status){
        case SETTING :{
		      //In this status, timer will not be changed
		       time_change=0;
	              }
	               break;
	case PAUSED  : {
		      //In this status, timer will not be changed
		       time_change=0;
	              }
	              break;
	case COUNTING: {
		       //In this status, timer will be changed 
		        time_change=1;
	               }
	              break;
	}
}