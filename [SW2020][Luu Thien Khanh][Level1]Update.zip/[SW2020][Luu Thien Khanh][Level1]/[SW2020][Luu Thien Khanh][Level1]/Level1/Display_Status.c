#include "lcd.h"
#include "Display_Status.h"
#include "stdio.h"

#define SETTING 1
#define PAUSED 2
#define COUNTING 3
extern int status;

/***************************************************************************************
* Function Name: Display_status
* Description  : Diplay status
* Arguments    : none
* Return Value : none
****************************************************************************************/

void Display_Status(void){
	switch (status){
        case SETTING :{
		      unsigned long i =10*1778;// Delay to dislay status clearly 
                      while (i!=0) i--;
		       DisplayLCD(LCD_LINE1, (uint8_t *)"SETTING");
	              }
	               break;
	case PAUSED  : {
		        //unsigned long i =10*1778;// Delay to dislay status clearly 
                        //while (i!=0) i--;
		       DisplayLCD(LCD_LINE1, (uint8_t *)"PAUSED");
	              }
	              break;
	case COUNTING: {
		        //unsigned long i =10*1778;// Delay to dislay status clearly 
                        //while (i!=0) i--;
		        DisplayLCD(LCD_LINE1, (uint8_t *)"COUNTING");
	               }
	              break;
	}
}