#include "r_macro.h"
#include "r_spi_if.h"
#include "lcd.h"      /* LCD driver interface */
#include "Port.h"
#include "iodefine.h"
#include "Check_Switch.h"

#define SETTING 1
#define PAUSED 2
#define COUNTING 3

extern int second;
extern int minute;
extern int status;
extern int Sw;
extern volatile int G_elapsedTime;

/******************************************************************************
* Function Name: Check_Switch
* Description  : Action for each switch
* Arguments    : none
* Return Value : none
******************************************************************************/
void Check_Switch(void) {
	    
	    switch (Sw){
		    case 1:/* Actions if Switch 1 are pressed */
	                   {if (status!=COUNTING){   
		           status = SETTING;
			   DisplayLCD(LCD_LINE1, (uint8_t *)"SETTING");
		           second = second +1;
		           if (second >=60){
		           second=0;
		           }
			   }
			   }
			   break;
	    
	            case 2: /* Actions if Switch 2 are pressed */
	                   {if (status!=COUNTING){
		             if (status==PAUSED){
	                    minute = 0;
	                    second = 0;
	                    } else {minute = minute +1;
	                      if (minute>=60){
		              minute=0;
	                     }
	                   }
	                   status = SETTING;
			    DisplayLCD(LCD_LINE1, (uint8_t *)"SETTING");
	                   }
			   }
			   break;
                    case 3: /* Actions if Switch 3 are pressed */
		          {
		           if (status == COUNTING){
		           status = PAUSED;
			   DisplayLCD(LCD_LINE1, (uint8_t *)"PAUSED");
			  
		          }
			   else if (status == PAUSED){
		           status = COUNTING;
			   DisplayLCD(LCD_LINE1, (uint8_t *)"COUNTING");
			   //G_elapsedTime=0;
		          }
		          else if (status == SETTING){
		          status = COUNTING;
			  DisplayLCD(LCD_LINE1, (uint8_t *)"COUNTING");
			  G_elapsedTime=0;
		          }
	            }
			   break;
		   default : break;
	
	    }
}